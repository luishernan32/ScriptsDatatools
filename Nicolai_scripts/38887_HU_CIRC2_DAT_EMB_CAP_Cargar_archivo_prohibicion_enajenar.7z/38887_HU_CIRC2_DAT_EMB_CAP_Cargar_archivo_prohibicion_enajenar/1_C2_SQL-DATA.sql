INSERT INTO circulemos2.dbo.parametro (
	codigo_parametro
	,codigo_modulo
	,nombre_parametro
	,codigo_tipo_variable
	,valor_parametro_defecto
	,codigo_unidad_parametro
	,formato
	,editable_organismo
	)
VALUES (
	434
	,2
	,N'LIMITE_SOLICITUD_BIEN_ENAJENAR'
	,1
	,N'2000'
	,NULL
	,NULL
	,1
	);

INSERT INTO circulemos2.dbo.tipo_cargue_archivo (
	id_tipo_cargue_archivo
	,nombre
	,codigo
	,sigla
	,descripcion
	,estado
	)
VALUES (
	20
	,N'Bien prohibicion enajenar'
	,N'20'
	,NULL
	,N'Prohibici�n de enajenar'
	,1
	);

INSERT INTO circulemos2.dbo.tipo_documento_proceso (
	id_tipo_documento_proceso
	,codigo
	,nombre
	,sigla
	,estado
	,descripcion
	)
VALUES (
	54
	,N'54'
	,N'GENERACION OFICIO BIEN PROHIBICI�N ENAJENAR'
	,NULL
	,1
	,N'GENERACION OFICIO BIEN PROHIBICI�N ENAJENAR'
	);